Of Fish and Chips
=================

Known Issues:

- Problem: The game may refuse to run and asks for openal.
- Solution: Install openal. It can be obtained here: http://connect.creativelabs.com/openal/default.aspx